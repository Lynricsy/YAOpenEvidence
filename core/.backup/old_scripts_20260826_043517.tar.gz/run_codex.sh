#!/usr/bin/env bash
# Launch Codex against the local Qwen stack.  Usage:
#   ./run_codex.sh                      # interactive TUI
#   ./run_codex.sh "你的医学文献问题"     # one-shot (codex exec)
export PATH="$HOME/.local/bin:$PATH"
export LOCAL_QWEN_KEY="sk-123456"          # must match master_key in litellm_config.yaml
# export S2_API_KEY=""                     # optional: Semantic Scholar key (higher rate limit)
cd /data1/qyy/smk
if ! curl -s -m 3 -H "Authorization: Bearer $LOCAL_QWEN_KEY" http://127.0.0.1:4000/v1/models >/dev/null; then
  echo "LiteLLM/vLLM not running. Start with: ./start_all.sh   (then ./status.sh)"; exit 1
fi
if [ $# -gt 0 ]; then
  mkdir -p answers
  OUT="answers/$(date +%Y%m%d_%H%M%S).md"
  { echo "# Q: $*"; echo; } > "$OUT"
  codex exec --skip-git-repo-check --output-last-message "$OUT.tmp" "$*" < /dev/null
  sed 's/<think>.*<\/think>//' "$OUT.tmp" 2>/dev/null | awk 'BEGIN{skip=0} /<think>/{skip=1} /<\/think>/{skip=0; next} !skip' >> "$OUT"
  rm -f "$OUT.tmp"
  echo; echo "答案已保存: /data1/qyy/smk/$OUT"
else
  exec codex
fi
