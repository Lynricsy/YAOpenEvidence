#!/usr/bin/env bash
# LiteLLM proxy on port 4000 (Codex talks to this).
set -e
ENV=/data/anaconda3/envs/clarify
export PATH="$ENV/bin:$PATH"
mkdir -p /data1/qyy/smk/logs
cd /data1/qyy/smk
echo "Starting LiteLLM proxy -> http://127.0.0.1:4000  (log: /data1/qyy/smk/logs/litellm.log)"
exec "$ENV/bin/litellm" --config /data1/qyy/smk/litellm_config.yaml --port 4000 --host 127.0.0.1 2>&1 | tee -a /data1/qyy/smk/logs/litellm.log
