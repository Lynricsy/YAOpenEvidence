#!/usr/bin/env bash
# Institutional-access helper.  ./paywall.sh login [URL]   |   ./paywall.sh get DOI
cd /data1/qyy/smk
export PYTHONPATH=/data1/qyy/smk/vendor
exec /data/anaconda3/envs/clarify/bin/python paywall_fetch.py "$@"
