#!/usr/bin/env bash
echo "--- tmux ---"; tmux list-windows -t smk 2>&1
echo "--- vLLM  :8000 ---"; curl -s -m 3 http://127.0.0.1:8000/v1/models | python3 -c "import sys,json;print([m['id'] for m in json.load(sys.stdin)['data']])" 2>/dev/null || echo "not ready"
echo "--- LiteLLM :4000 ---"; curl -s -m 3 -H "Authorization: Bearer sk-123456" http://127.0.0.1:4000/v1/models | python3 -c "import sys,json;print([m['id'] for m in json.load(sys.stdin)['data']])" 2>/dev/null || echo "not ready"
echo "--- GPU ---"; nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv,noheader
