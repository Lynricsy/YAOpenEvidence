#!/usr/bin/env bash
# One-shot literature QA pipeline: search -> download full text -> read -> cited answer.
# Usage: ./ask.sh "你的问题"   [extra args: --papers 10 --max-chars 20000]
export LOCAL_QWEN_KEY="${LOCAL_QWEN_KEY:-sk-123456}"
cd /data1/qyy/smk
exec /data/anaconda3/envs/clarify/bin/python ask.py "$@"
