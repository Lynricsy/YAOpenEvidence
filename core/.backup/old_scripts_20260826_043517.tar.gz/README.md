# smk — Codex + local Qwen + Semantic Scholar 医学文献问答 demo

```
Codex CLI ──(OpenAI Responses API)──> LiteLLM :4000 ──> vLLM :8000 (Qwen3-14B, GPU 2)
   │
   └── MCP: semantic_scholar_mcp.py ──> api.semanticscholar.org
```

## 目录
| 文件 | 作用 |
|---|---|
| `semantic_scholar_mcp.py` | MCP 服务（stdio）。Semantic Scholar 工具：`search_papers` `get_paper` `get_citations` `get_references` `get_recommendations` `search_authors`；PubMed 后备：`pubmed_search` `pubmed_fetch`（S2 限流 429 时 `search_papers` 自动切到 PubMed）；全文：`get_fulltext`（Europe PMC 开放获取全文，按章节读）、`read_pdf`（读 `pdfs/` 下本地 PDF） |
| `litellm_config.yaml` | LiteLLM 代理配置，把 vLLM 包装成带 `/v1/responses` 的 OpenAI 接口 |
| `start_vllm.sh` / `start_litellm.sh` | 单独启动 |
| `start_all.sh` / `stop_all.sh` / `status.sh` | 一键在 tmux 里启动 / 停止 / 查看两个服务状态 |
| `ask.sh` / `ask.py` | **一键流水线**：问题 → 生成检索词 → PubMed+Europe PMC 检索 → 下载全文(PMC XML / Unpaywall PDF) → 模型逐篇阅读做笔记 → 综合成带 [n] 引用的答案。输出 `answers/<ts>.md` + `answers/<ts>_papers/`（每篇全文和阅读笔记）|
| `run_codex.sh` | 启动 Codex（设好 PATH / LOCAL_QWEN_KEY，检查服务是否在跑）|
| `AGENTS.md` | Codex 在本目录下的系统指令（文献检索工作流 + 回答格式） |
| `paywall_fetch.py` / `paywall.sh` | 机构订阅全文下载（Playwright）。复用 SPIDER_PROJECT 的登录态格式 `sd_state.json`（+`.session_storage.json` `.context.json`）和其拦截页检测规则（`spider_auth.py` 即 SPIDER 的 `human_auth.py`）。`login` 在有显示器的机器上登录一次；`get DOI` 无头下载 |
| `verify_citations.py` | 核对最近一次回答里的 PMID/DOI 是否都来自工具返回（防编造）：`python3 verify_citations.py` |
| `test_mcp.py` | 不用模型，直接测 Semantic Scholar 工具 |
| `~/.codex/config.toml` | Codex 全局配置（模型、provider、MCP server） |

## 启动
```bash
cd /data1/qyy/smk
./start_all.sh            # 默认 Qwen3-14B 放 GPU 2；小模型: ./start_all.sh 4b 1
./status.sh               # 等到 vLLM / LiteLLM 都显示模型名
./run_codex.sh            # 进入交互式 agent（在本目录下自动读 AGENTS.md）
```
**推荐：一键流水线（确定性，每次都检索+下载全文+阅读）**
```bash
./ask.sh "SGLT2抑制剂对HFpEF患者有什么获益？"
./ask.sh --papers 12 "..."        # 多读几篇（默认 8 篇，约 2-4 分钟）
```
参考文献每条后面标注〔全文(PMC)〕/〔全文(PDF)〕/〔仅摘要〕，`answers/<ts>_papers/` 里能看到每篇的原文和模型笔记。

Codex 交互式（模型自己决定调哪些工具，适合追问）：
```bash
./run_codex.sh "SGLT2 抑制剂对射血分数保留的心衰患者有什么获益？请查文献回答"
```
停止：`./stop_all.sh`

## Codex 配置要点（`~/.codex/config.toml`，原文件备份在 `config.toml.bak_*`）
- `model = "qwen3-14b"`, `model_provider = "local-qwen"`, provider `base_url = http://127.0.0.1:4000/v1`, `wire_api = "responses"`
  （LiteLLM 会把 Responses API 转成 vLLM 的 chat/completions，Qwen3 的 thinking 与 tool call 都能正常透传）
- `env_key = "LOCAL_QWEN_KEY"` → 环境变量值要等于 LiteLLM 的 `master_key`（run_codex.sh 已设置）
- `[mcp_servers.semantic_scholar] default_tools_approval_mode = "approve"` —— 关键！否则 `codex exec` 下
  MCP 工具调用会报 "requires approval, but approval policy is never"，模型就会凭记忆编参考文献。
  （该版本 0.149 的取值是 `approve | prompt | writes`，没有 `auto`）

## 环境
- conda env `clarify`（vllm 0.27 / litellm 1.98 / mcp 1.29）
- Codex CLI 装在 `~/.local/bin/codex`
- 可选：`export S2_API_KEY=...` 提高 Semantic Scholar 速率限制（免费申请：https://www.semanticscholar.org/product/api）。
  目前无 key 时 S2 基本一直 429，`search_papers` 会自动退到 PubMed（NCBI E-utilities，免 key 可用），demo 不受影响。
- 可选：`NCBI_API_KEY` 提高 PubMed 速率（3→10 req/s）

## 排错
- `tmux attach -t smk` 看 vLLM / LiteLLM 日志；`logs/` 下也有
- `curl -H "Authorization: Bearer sk-123456" http://127.0.0.1:4000/v1/models` 应列出 `qwen3-14b`
- 想直接测工具：`conda activate clarify && python test_mcp.py`

## 怎么确认答案不是编的
1. 运行输出里必须有 `mcp: semantic_scholar/xxx (completed)`；没有 `mcp:` 行或显示 `(failed)` 就是凭记忆答的。
2. `python3 verify_citations.py` —— 读取最近一次会话，把答案里的 PMID/DOI 与工具返回逐一比对，
   不在工具返回里的标 `SUSPECT`。
3. 具体数字（HR、样本量）要核对原文时，在对话里追问："把 [2] 的摘要原文贴出来" 或
   "用 pubmed_fetch 36041474"，对照摘要看数字是否一致。
4. 完整原始记录（含工具返回全文）在 `~/.codex/sessions/<date>/rollout-*.jsonl`。

## 全文怎么读
- 开放获取（PMC 收录）的文章：对话里说 "读一下 [2] 的全文 Results 部分"，模型会调 `get_fulltext`，
  先列章节再按章节取（32k 上下文，一次别超过 2 万字符）。
- 付费墙文章（Elsevier / NEJM / IEEE 等）：没有合法匿名接口。把通过机构订阅下载的 PDF 放到
  `/data1/qyy/smk/pdfs/`，然后说 "用 read_pdf 读 xxx.pdf"。SPIDER_PROJECT 爬下来的 PDF 可以直接放进来。
- 依赖：`pypdf` 装在项目自带的 `vendor/` 目录（`pip install --target vendor pypdf`），不影响 conda 环境。

## 机构订阅全文（SPIDER_PROJECT 集成）
流程：`ask.py` 找不到 PMC / Unpaywall 开放全文时，如果存在 `sd_state.json`，就用保存的机构登录态无头打开
`https://doi.org/<DOI>`，按出版社规则（ScienceDirect `pdfft`、Wiley `pdfdirect`、Springer `content/pdf`、
Nature `.pdf`、NEJM/T&F `doi/pdf`、Lancet/Cell `showPdf`、IEEE `stampPDF`、`citation_pdf_url` meta…）拿 PDF，
参考文献标注〔全文(机构订阅)〕。每次回答最多下 `PAYWALL_MAX_PER_RUN`（默认 5）篇，串行、每篇间隔 4–9 秒。

**第一步：在有显示器的机器上登录一次**（你的电脑 / AWS 的 RDP 桌面都行；服务器没有显示器）
```bash
# AWS 上（已建好 venv）：
cd /home/ubuntu/smk/medlit_codex_backup && ./.venv/bin/python paywall_fetch.py login --url https://www.sciencedirect.com/
# 浏览器弹出 → 走机构登录（OpenAthens / Shibboleth / CARSI）→ 打开一篇付费文章确认能看全文 → 回终端按 Enter
scp sd_state.json* tx@10.107.231.69:/data1/qyy/smk/
```
**第二步：服务器上测试单篇**
```bash
./paywall.sh get 10.1016/j.jacc.2023.10.021     # 成功会写到 pdfs/
```
**第三步**：之后 `./ask.sh "问题"` 自动启用；`--no-paywall` 可关闭。

注意：登录态里的 cookie 可能与出口 IP 绑定（IP 段授权的学校）。若在校园网内登录、在校外服务器使用被拒，
需要把服务器出口走校园 VPN，或直接在校园网内的机器上部署。请只按需下载，遵守出版社许可。
