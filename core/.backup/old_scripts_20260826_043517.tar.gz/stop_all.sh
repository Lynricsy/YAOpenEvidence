#!/usr/bin/env bash
tmux kill-session -t smk 2>/dev/null && echo "stopped tmux session smk"
pkill -f "vllm serve" 2>/dev/null; pkill -f "litellm --config" 2>/dev/null
echo "done"
