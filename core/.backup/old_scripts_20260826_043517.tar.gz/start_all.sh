#!/usr/bin/env bash
# Start vLLM + LiteLLM in a detached tmux session "smk". Usage: ./start_all.sh [14b|4b] [GPU_ID]
SIZE="${1:-14b}"; GPU="${2:-2}"
cd /data1/qyy/smk
if tmux has-session -t smk 2>/dev/null; then echo "tmux session 'smk' already running (tmux attach -t smk)"; exit 0; fi
tmux new-session -d -s smk -n vllm "bash /data1/qyy/smk/start_vllm.sh $SIZE $GPU; echo VLLM EXITED; sleep 999999"
tmux new-window -d -t smk -n litellm "sleep 15; bash /data1/qyy/smk/start_litellm.sh; echo LITELLM EXITED; sleep 999999"
echo "Started in tmux session 'smk'. vLLM needs 1-3 min to load the model."
echo "Check:  ./status.sh      Logs:  tmux attach -t smk"
